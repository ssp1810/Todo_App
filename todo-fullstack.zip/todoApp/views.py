import json
from django.shortcuts import render
from rest_framework import views 
from rest_framework.response import Response


class NotesView(views.APIView):
    def post(self, request):
        # POST request for notes creation
        
        notes_data = json.loads(request)
        notes_service = NotesService(notes_data)