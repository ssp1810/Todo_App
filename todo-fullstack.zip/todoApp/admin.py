from django.contrib import admin
from .models import Notes

# Register your model in django admin
admin.site.register(Notes)