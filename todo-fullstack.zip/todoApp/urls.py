from django.contrib import admin
from django.urls import path, include
from todoApp.views import NotesView
urlpatterns = [
    path('createNote/', NotesView.as_view),
]