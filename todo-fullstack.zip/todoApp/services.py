from django.db import transaction
from todoApp.serializers import NotesSerializer

class NotesService:
    """
    Service layer for operations on notes
    """
    def __init__(self, request):
        self.request = request
        
    def create_note(self, request):
        """
        Creating a new note
        """
        data = request
        with transaction.atomic():
            serialized_notes_data = NotesSerializer(data = data)